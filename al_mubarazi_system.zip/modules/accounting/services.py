from database.crud import create_invoice, get_total_sales, get_total_profit
from sqlalchemy.orm import Session

class AccountingService:
    @staticmethod
    def record_sale(db: Session, customer_id: int, invoice_number: str, amount: float, cost: float, item_type: str, photo_path: str = None):
        """
        تسجيل عملية بيع وحساب الربح.
        """
        profit = amount - cost
        return create_invoice(db, customer_id, invoice_number, amount, profit, item_type, photo_path)

    @staticmethod
    def get_financial_report(db: Session):
        """
        الحصول على تقرير مالي موجز.
        """
        total_sales = get_total_sales(db)
        total_profit = get_total_profit(db)
        return {
            "total_sales": total_sales,
            "total_profit": total_profit,
            "net_margin": (total_profit / total_sales * 100) if total_sales > 0 else 0
        }

    @staticmethod
    def notify_warehouse(item_details: str):
        """
        محاكاة إرسال إشعار للمستودع (يمكن ربطه بـ API لاحقاً).
        """
        # في بيئة Termux، يمكن إرسال رسالة Telegram أو حفظها في ملف للمزامنة
        print(f"إشعار للمستودع: مطلوب تجهيز {item_details}")
        return True

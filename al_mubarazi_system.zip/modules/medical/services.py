from database.crud import add_medical_record, get_customer_by_phone, create_customer
from sqlalchemy.orm import Session

class MedicalService:
    @staticmethod
    def save_optics_exam(db: Session, phone: str, name: str, re_sph: str, re_cyl: str, re_ax: str, le_sph: str, le_cyl: str, le_ax: str):
        """
        حفظ بيانات فحص النظر لعميل.
        """
        customer = get_customer_by_phone(db, phone)
        if not customer:
            customer = create_customer(db, name, phone)
        
        return add_medical_record(
            db, 
            customer_id=customer.id, 
            record_type='optics',
            right_eye_sphere=re_sph,
            right_eye_cylinder=re_cyl,
            right_eye_axis=re_ax,
            left_eye_sphere=le_sph,
            left_eye_cylinder=le_cyl,
            left_eye_axis=le_ax
        )

    @staticmethod
    def save_audiology_exam(db: Session, phone: str, name: str, loss_level: str, notes: str):
        """
        حفظ بيانات فحص السمع لعميل.
        """
        customer = get_customer_by_phone(db, phone)
        if not customer:
            customer = create_customer(db, name, phone)
            
        return add_medical_record(
            db,
            customer_id=customer.id,
            record_type='audiology',
            hearing_loss_level=loss_level,
            audiogram_notes=notes
        )

    @staticmethod
    def get_customer_history(db: Session, phone: str):
        """
        استرجاع سجل العميل الطبي والمالي.
        """
        customer = get_customer_by_phone(db, phone)
        if not customer:
            return None
        
        return {
            "info": {"name": customer.name, "phone": customer.phone},
            "medical": customer.medical_records,
            "invoices": customer.invoices
        }
